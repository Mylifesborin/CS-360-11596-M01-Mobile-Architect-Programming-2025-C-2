package com.weighttrackerapp.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsNotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private TextView smsStatusText;
    private Button btnSendSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        smsStatusText = findViewById(R.id.smsStatusText);
        Button btnRequestPermission = findViewById(R.id.btnRequestPermission);
        btnSendSms = findViewById(R.id.btnSendSms);

        btnSendSms.setEnabled(false); // disabled until permission granted

        btnRequestPermission.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                smsStatusText.setText("Permission already granted");
                btnSendSms.setEnabled(true);
            }
        });

        btnSendSms.setOnClickListener(v -> {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("1234567890", null,
                        "Goal weight reached! 🎉 Keep it up!", null, null);
                Toast.makeText(this, "SMS sent!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsStatusText.setText("SMS permission granted");
                btnSendSms.setEnabled(true);
            } else {
                smsStatusText.setText("SMS permission denied. Notifications disabled.");
                btnSendSms.setEnabled(false);
            }
        }
    }
}
