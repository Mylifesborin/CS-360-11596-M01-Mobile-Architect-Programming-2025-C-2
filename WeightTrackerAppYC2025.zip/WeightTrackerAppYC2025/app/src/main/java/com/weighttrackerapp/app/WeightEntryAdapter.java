package com.weighttrackerapp.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.ViewHolder> {

    private List<WeightEntry> weightEntries;

    public WeightEntryAdapter(List<WeightEntry> weightEntries) {
        this.weightEntries = weightEntries;
    }

    @NonNull
    @Override
    public WeightEntryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.dateText.setText(entry.getDate());
        holder.weightText.setText(entry.getWeight());

        holder.deleteButton.setOnClickListener(v -> {
            weightEntries.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, weightEntries.size());
        });
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateText, weightText;
        Button deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.textDate);
            weightText = itemView.findViewById(R.id.textWeight);
            deleteButton = itemView.findViewById(R.id.btnDelete);
        }
    }
}
